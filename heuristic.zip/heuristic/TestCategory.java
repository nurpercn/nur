package tr.testodasi.heuristic;

public enum TestCategory {
  GAS,
  PULLDOWN,
  OTHER,
  CONSUMER_USAGE;
}